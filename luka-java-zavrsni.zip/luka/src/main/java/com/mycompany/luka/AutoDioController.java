package com.mycompany.luka;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.swing.*;
import java.awt.event.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * This is the Controller in the MVC model. This will act
 * as the communication between the Model(data) and View.
 * This can manipulate, update the values of the Model when
 * an action is performed from the View. Also, this is where
 * you add your listeners to your view in order that it will
 * fire an event, which can update values in your model, or
 * update your view.
 */

public class AutoDioController {

    private Session session;
    
  /*  private View view;
    private AutoDio model;
    private TableModel tableModel;
    private List<AutoDio> autoDijelovi;*/

    public AutoDioController() {
        session = HibernateSingleton.getSession();
    }
    
    public List<AutoDio> dohvatiDijelove(){
        return session.createQuery("from AutoDio", AutoDio.class).list();
    }
    
    public void saveModel(AutoDio dio){
        session.beginTransaction();
        session.persist(dio);
        session.getTransaction().commit();
    }
    
    public void obrisiModel(AutoDio dio) throws Exception{
        session.beginTransaction();
        session.remove(dio);
        session.getTransaction().commit();
    }

    /*class AddButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String naziv = view.getNazivField().getText();
            String sifra = view.getSifraField().getText();
            if (!naziv.isEmpty() && !sifra.isEmpty()) {
                try {
                    System.out.println("Dodaj novo");

                    // int age = Integer.parseInt(ageText);
                    tableModel.addItem(new Dio(1234,naziv, sifra));
                    view.getNazivField().setText("");
                    view.getSifraField().setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(view, "Dogodila se greška.");
                }
            } else {
                JOptionPane.showMessageDialog(view, "Sva polja moraju biti popunjena.");
            }
        }
    }*/

   /* class ReloadButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Reload table data (e.g., from a data source)
                List<Dio> items = new ArrayList<>();
                items.add(new Dio(123,"John Doe", "sadas"));
                items.add(new Dio(342,"Jane Smith", "3231"));
            tableModel.reloadItems(items);
        }
    }*/

    /*private List<AutoDio> dohvatiDijelove(){
        Configuration cfg = new Configuration();
        cfg.configure();

        // get session factory
        SessionFactory sessionfactory = cfg.buildSessionFactory();

        // get session object
        Session session = sessionfactory.openSession();

        CriteriaBuilder builder = session.getCriteriaBuilder();

        CriteriaQuery<AutoDio> criteria = builder.createQuery(AutoDio.class);

        criteria.from(AutoDio.class);

        List<AutoDio> autoDijelovi = session.createQuery(criteria).getResultList();

        session.close();
        sessionfactory.close();

        return autoDijelovi;

        // return session.createQuery("SELECT id, naziv, sifra, cijena FROM AutoDio").getResultList();
    }*/

}