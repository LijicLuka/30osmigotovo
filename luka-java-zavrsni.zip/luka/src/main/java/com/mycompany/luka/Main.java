/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.luka;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;


/**
 *
 * @author ideav
 */
public class Main {

    private static Connection connection;

    public static void main(String[] args) throws SQLException {
        /**
         * Hibernate stuff
         */


//        List<AutoDio> dijelovi = dohvatiDijelove(s);
//
//        for(AutoDio dio : dijelovi){
//            System.out.println(dio.toString());
//            System.out.println(dio.getId());
//        }

        // create AutoDio object
       /* AutoDio auto = new AutoDio(1234, "Kotač", "kotac-002", 22.33);

        s.save(auto);

        // Start the transaction
        Transaction tx = s.beginTransaction();

        tx.commit();

        */

        // close session and session factory


        /*openDatabaseConnection();
        closeDatabaseConnection();*/
     
        new DijeloviView().setVisible(true);
        // Just instantiate all the class that we made
        SwingUtilities.invokeLater(() -> {
       
          //  v.setVisible(true);
        });

    }
    
    private static void openDatabaseConnection() throws SQLException {
        System.out.println("Connecting to DB");
        connection = DriverManager.getConnection(
          "jdbc:mariadb://localhost:3306/luka_app","root", ""
        );
        System.out.println("Connection valid " + connection.isValid(5));
    }
    
    private static void closeDatabaseConnection() throws SQLException {
        System.out.println("Close DB");
        connection.close();
        System.out.println("Connection valid " + connection.isValid(5));
    }

    private static List<AutoDio> dohvatiDijelove(Session session){
        CriteriaBuilder builder = session.getCriteriaBuilder();

        CriteriaQuery<AutoDio> criteria = builder.createQuery(AutoDio.class);

        criteria.from(AutoDio.class);

        List<AutoDio> autoDijelovi = session.createQuery(criteria).getResultList();

        return autoDijelovi;

       // return session.createQuery("SELECT id, naziv, sifra, cijena FROM AutoDio").getResultList();
    }


}
