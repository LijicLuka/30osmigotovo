/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.luka;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author ideav
 */
public class HibernateSingleton {
    
    private static Session session = null;
    
    private HibernateSingleton(){
        session = new Configuration().configure().buildSessionFactory().openSession();
    }
    
    public static Session getSession(){
        if(session == null){
            new HibernateSingleton();
        }
        
        return session;
    }
    
}
