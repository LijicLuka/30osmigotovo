/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.luka;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;


/**
 *
 * @author ideav
 */

@Entity(name="AutoDio")
@Table(name="auto_dijelovi")
public class AutoDio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id;
    private String naziv;
    private String sifra;
    private BigDecimal cijena;

    public AutoDio(){
        super();
    }

    public AutoDio(int id, String naziv, String sifra, BigDecimal cijena) {
        Id = id;
        this.naziv = naziv;
        this.sifra = sifra;
        this.cijena = cijena;
    }



    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }
    
    public BigDecimal getCijena(){
        return cijena;
    }
    
    public void setCijena(BigDecimal cijena){
        this.cijena = cijena;
    }
    
    public String getCijenaStr(){
        return "Cijena: " + this.cijena.toString();
    }
    
    @Override
    public String toString(){
        return getNaziv() + ", " +getSifra() + ", " + getCijenaStr() ;
    }





    
}
